# Xem chi tiết cảnh báo theo hex

## Cập nhật

Thay mã nguồn bằng bản trong ZIP, giữ cấu hình `.env`, database và Docker volumes đang dùng. Trong thư mục dự án, chạy:

```bash
docker compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d --build monitor airflow-scheduler airflow-dag-processor airflow-api-server
```

Nếu chạy inference bằng service `pipeline` theo profile tools, build lại service đó trước lần chạy tiếp theo:

```bash
docker compose -f docker-compose.yml -f docker-compose.monitoring.yml --profile tools build pipeline
```

Không cần train lại model. Không chạy `down -v`. Bảng `monitor_feature_details` tự tạo khi inference ghi snapshot tiếp theo; tài khoản DB cần quyền tạo bảng như các bảng monitoring hiện có.

## Cách xem

1. Mở http://localhost:8001 (hoặc MONITOR_PORT đã cấu hình).
2. Trong Feature hoặc Performance, bấm **Xem chi tiết** ở đúng dòng loại xe / horizon / model.
3. Xem bảng mục 4, lọc đúng mã hex nếu cần. Mỗi trang 100 bản ghi.
4. Với Performance, chọn khung đánh giá trước khi bấm. Các dòng lỗi/chờ được xếp trước; dòng đủ điều kiện chấm được sắp theo sai số tuyệt đối giảm dần.

Feature: mã hex, feature thiếu, bucket nguồn gần nhất, độ cũ, thời điểm snapshot và lý do. Thiếu feature ở một ô chưa nhất thiết vượt tỷ lệ cảnh báo của toàn nhóm. Snapshot cũ là vấn đề toàn nhóm, không phải lỗi riêng từng hex.

Performance: mã hex, mốc dự báo, prediction, actual đã nhận, số bucket có/cần, mốc bucket còn thiếu, thời điểm đủ tuổi chấm, lý do và sai số khi đủ điều kiện. Actual chưa đủ bucket là tổng từng phần, không phải nhãn đầy đủ. Đếm bản ghi dự đoán, không đếm hex duy nhất.

Pending = chưa tới T + horizon + thời gian chờ; missing_actual = đã tới hạn nhưng actual không đủ. Late là phát hành trễ, có thể đồng thời thiếu/chờ actual. Dòng eligible không phải cảnh báo. Actual bằng 0 vẫn được tính sai số tuyệt đối nếu đủ điều kiện.

## Dữ liệu và giới hạn

- Feature được lưu trong PostgreSQL `monitor_feature_details`, theo mốc dự báo / loại xe / horizon / model. Không sửa prediction hay dữ liệu huấn luyện.
- Snapshot cũ trước nâng cấp không có chi tiết và không được dựng giả. Độ cũ nguồn/snapshot được tính lại tại thời điểm xem.
- Chi tiết Performance dùng cùng hàm `prepare()` với job chấm điểm; đọc archive và actual hiện có. Actual đến muộn có thể làm kết quả khác snapshot tổng hợp đã chấm; giao diện ghi rõ thời điểm truy vấn.
- Trang demo không truy dữ liệu production và không có nút drilldown.
- PSI là cảnh báo phân phối nhóm; xem histogram và khoảng tham chiếu ở mục 3, không gán PSI thành lỗi từng hex.
- Bảng feature lưu lịch sử, chưa tự xóa; nên thiết lập chính sách lưu giữ phù hợp khi vận hành dài hạn.
- Chưa có nút nhảy trực tiếp sang bản đồ. Mã hex hiển thị đầy đủ để tra cứu.

## API

`GET /details` nhận `kind=feature|performance`, `start`, `end` (ISO 8601 có múi giờ, khoảng tối đa 24 giờ), `travel_mode`, `horizon_minutes`, `model_version`, tùy chọn `hex_id`, `offset`, `limit` (tối đa 500).

Với feature, có thể dùng khoảng thời gian để tra lịch sử snapshot đã lưu; giao diện chọn đúng mốc snapshot hiện tại. API trả `rows`, `total`, `evaluated_at`, `note`. Performance có giới hạn MONITOR_MAX_ROWS và timeout truy vấn; API trả 503 thay vì âm thầm cắt dữ liệu.

## Kiểm thử

```bash
python -m pytest tests/test_monitoring_details.py test_monitoring.py -q
```

Các test mới kiểm tra định danh hex/feature thiếu, độ cũ, pending vs missing, bucket thiếu chính xác, actual bằng 0, phát hành trễ, bộ lọc, phân trang và kiểm tra thời gian đầu vào API.

Kết quả kiểm tra bản giao: 19 test đạt với `-k 'not replay_isolation_and_no_future_features'`; JavaScript qua `node --check`, Python qua kiểm tra biên dịch. Test replay cũ chưa chạy được trong môi trường sửa code vì thiếu pyarrow. Chưa chạy tích hợp trên PostgreSQL hoặc Docker thực tế của người dùng; cần kiểm tra sau khi triển khai.
