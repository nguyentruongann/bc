"""Read-only drilldown, with feature evidence retained at inference time."""
import math
import pandas as pd
from fastapi import HTTPException, Query
from .monitoring import prepare
from .monitoring_config import MonitorConfig


def save_feature_detail(conn, settings, snapshot):
    from psycopg import sql
    from psycopg.types.json import Jsonb
    from .monitoring_store import table
    target=table(settings,'monitor_feature_details')
    conn.execute(sql.SQL('''CREATE TABLE IF NOT EXISTS {} (
        forecast_start_utc timestamptz NOT NULL, travel_mode text NOT NULL,
        horizon_minutes integer NOT NULL, model_version text NOT NULL,
        observed_at timestamptz NOT NULL, payload jsonb NOT NULL,
        PRIMARY KEY(forecast_start_utc,travel_mode,horizon_minutes,model_version))''').format(target))
    conn.execute(sql.SQL('''INSERT INTO {} VALUES (%s,%s,%s,%s,%s,%s)
        ON CONFLICT (forecast_start_utc,travel_mode,horizon_minutes,model_version)
        DO UPDATE SET observed_at=EXCLUDED.observed_at,payload=EXCLUDED.payload''').format(target),
        (snapshot['forecast_start_utc'],snapshot['travel_mode'],snapshot['horizon_minutes'],
         snapshot['model_version'],snapshot['observed_at'],Jsonb(snapshot)))


def feature_rows(snapshot, now, config):
    rows=[]
    stale=(pd.Timestamp(now)-pd.Timestamp(snapshot['observed_at'])).total_seconds()>config.feature_delay_warning_seconds
    for item in snapshot.get('detail_rows',[]):
        last=item['latest_bucket_utc']
        age=None if last is None else max(0,(pd.Timestamp(now)-pd.Timestamp(last)-pd.Timedelta(minutes=10)).total_seconds())
        reasons=[]
        if last is None: reasons.append('hex_history_missing')
        elif age>config.feature_delay_warning_seconds: reasons.append('source_stale_or_missing')
        if item['missing_features']: reasons.append('missing_feature')
        if stale: reasons.append('feature_snapshot_stale (cả snapshot)')
        if reasons:
            rows.append(dict(item,reason='; '.join(reasons),source_age_minutes=None if age is None else age/60,
                missing_features=', '.join(item['missing_features']),forecast_start_utc=snapshot['forecast_start_utc'],
                observed_at=snapshot['observed_at']))
    return rows


def performance_rows(frame, now, config):
    rows=[]
    for r in prepare(frame,now,config.label_wait_seconds,config.issue_grace_seconds).to_dict('records'):
        expected=list(pd.date_range(r['forecast_start_utc'],periods=int(r['horizon_minutes'])//10,freq='10min'))
        present={pd.Timestamp(t) for t in (r.get('buckets') or [])}
        reasons=[]
        if not r['mature']: reasons.append('pending_actual')
        elif not r['complete']: reasons.append('missing_actual')
        if not r['on_time']: reasons.append('late_prediction')
        actual=r['actual']
        actual=None if actual is None or not math.isfinite(float(actual)) else float(actual)
        rows.append(dict(hex_id_7=r['hex_id_7'],forecast_start_utc=r['forecast_start_utc'].isoformat(),
            reason='; '.join(reasons) or 'eligible',predicted_demand=r['predicted_demand'],
            actual=actual,expected_buckets=len(expected),bucket_count=int(r['bucket_count']),
            missing_buckets=', '.join(t.isoformat() for t in expected if t not in present),
            eligible_at=(expected[0]+pd.Timedelta(minutes=int(r['horizon_minutes']),seconds=config.label_wait_seconds)).isoformat(),
            absolute_error=abs(r['predicted_demand']-actual) if r['eligible'] else None))
    return rows


def register(app):
    @app.get('/details')
    def details(kind:str, start:str, end:str, travel_mode:str, horizon_minutes:int,
                model_version:str, hex_id:str='', offset:int=Query(0,ge=0), limit:int=Query(100,ge=1,le=500)):
        import psycopg
        from psycopg import sql
        from .config import get_settings
        from .monitoring_store import table,load_evaluation
        try:
            a,b=pd.Timestamp(start),pd.Timestamp(end)
            if a.tzinfo is None or b.tzinfo is None or not pd.Timedelta(0)<b-a<=pd.Timedelta(hours=24):
                raise ValueError()
        except (ValueError,TypeError):
            raise HTTPException(422,'Khoảng thời gian phải có múi giờ, lớn hơn 0 và không quá 24 giờ') from None
        if kind not in ('feature','performance') or travel_mode not in ('Car','Motorcycle') or horizon_minutes not in (10,30,60):
            raise HTTPException(422,'Bộ lọc không hợp lệ')
        settings=get_settings();c=MonitorConfig.from_env();now=pd.Timestamp.now(tz='UTC')
        try:
            if kind=='feature':
                with psycopg.connect(settings.require_database_url(),connect_timeout=5) as conn:
                    conn.execute("SET statement_timeout='15s'")
                    # Old installations have no historical per-hex snapshots.
                    exists=conn.execute('SELECT to_regclass(%s)',(settings.postgres_schema+'.monitor_feature_details',)).fetchone()[0]
                    snapshots=[] if exists is None else conn.execute(sql.SQL('''SELECT payload FROM {}
                        WHERE forecast_start_utc >= %s AND forecast_start_utc < %s
                        AND travel_mode=%s AND horizon_minutes=%s AND model_version=%s
                        ORDER BY forecast_start_utc DESC''').format(table(settings,'monitor_feature_details')),
                        (a,b,travel_mode,horizon_minutes,model_version)).fetchall()
                rows=[row for (snapshot,) in snapshots for row in feature_rows(snapshot,now,c)]
                note='Chi tiết feature chỉ có từ lần inference sau khi nâng cấp. Độ cũ tính tại thời điểm xem; missing_feature là từng ô thiếu, chưa chắc vượt ngưỡng warning tổng hợp.'
            else:
                frame=load_evaluation(settings,a,b,details=True)
                frame=frame.loc[(frame.travel_mode==travel_mode)&(frame.horizon_minutes==horizon_minutes)&(frame.model_version==model_version)]
                rows=performance_rows(frame,now,c)
                rows.sort(key=lambda r:(r['reason']=='eligible',-(r['absolute_error'] or 0),r['forecast_start_utc'],r['hex_id_7']))
                note='Tính lại với actual hiện có; có thể khác khung đã chấm nếu actual đến muộn. Actual chưa đủ bucket chỉ là tổng từng phần. eligible không phải cảnh báo.'
        except (psycopg.Error,RuntimeError):
            raise HTTPException(503,'Không tải được chi tiết; kiểm tra kết nối DB hoặc thu hẹp khung thời gian.') from None
        if hex_id: rows=[r for r in rows if r['hex_id_7']==hex_id]
        return dict(rows=rows[offset:offset+limit],total=len(rows),offset=offset,limit=limit,note=note,
                    evaluated_at=now.isoformat(),travel_mode=travel_mode,horizon_minutes=horizon_minutes,model_version=model_version)
