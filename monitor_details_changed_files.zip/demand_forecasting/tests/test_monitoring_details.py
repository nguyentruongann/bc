import pandas as pd
import numpy as np
from fastapi import FastAPI
from fastapi.testclient import TestClient
from demand_forecasting.monitoring_config import MonitorConfig
from demand_forecasting.monitoring_details import feature_rows, performance_rows, register
from demand_forecasting.feature_monitor import measure

T=pd.Timestamp('2026-10-16T00:00:00Z')
C=MonitorConfig()

def test_feature_evidence_identifies_exact_hex_and_column():
    frame=pd.DataFrame({'hex_id_7':['a','b'],'lag_10m':[1.,np.nan]})
    raw=pd.DataFrame({'hex_id_7':['a'],'travel_mode':['Car'],'period_datetime_utc':[T-pd.Timedelta(minutes=10)]})
    snapshot=measure(frame,['lag_10m'],raw,T,'Car',10,'v1',now=T)
    rows=feature_rows(snapshot,T,C)
    assert len(rows)==1 and rows[0]['hex_id_7']=='b'
    assert rows[0]['missing_features']=='lag_10m'
    assert 'hex_history_missing' in rows[0]['reason']
    later=feature_rows(snapshot,T+pd.Timedelta(hours=1),C)
    assert len(later)==2 and 'source_stale_or_missing' in later[0]['reason']

def frame():
    return pd.DataFrame([dict(hex_id_7='a',forecast_start_utc=T,issued_at=T,
        horizon_minutes=30,predicted_demand=8.,actual=3.,bucket_count=2,
        buckets=[T,T+pd.Timedelta(minutes=20)])])

def test_pending_missing_late_and_complete_use_same_eligibility():
    f=frame()
    pending=performance_rows(f,T,C)[0]
    assert pending['reason']=='pending_actual' and pending['absolute_error'] is None
    missing=performance_rows(f,T+pd.Timedelta(hours=1),C)[0]
    assert missing['reason']=='missing_actual'
    assert missing['missing_buckets']=='2026-10-16T00:10:00+00:00'
    f.at[0,'bucket_count']=3;f.at[0,'actual']=0.
    f.at[0,'buckets']=[T,T+pd.Timedelta(minutes=10),T+pd.Timedelta(minutes=20)]
    ready=performance_rows(f,T+pd.Timedelta(hours=1),C)[0]
    assert ready['reason']=='eligible' and ready['absolute_error']==8.
    f.at[0,'issued_at']=T+pd.Timedelta(minutes=5)
    late=performance_rows(f,T+pd.Timedelta(hours=1),C)[0]
    assert late['reason']=='late_prediction' and late['absolute_error'] is None

def test_details_rejects_invalid_window_before_database_access():
    app=FastAPI();register(app);client=TestClient(app)
    query=dict(kind='performance',start='2026-10-16',end='2026-10-17',travel_mode='Car',horizon_minutes=10,model_version='v1')
    assert client.get('/details',params=query).status_code==422
    query.update(start=T.isoformat(),end=(T+pd.Timedelta(days=2)).isoformat())
    assert client.get('/details',params=query).status_code==422

def test_detail_api_filters_and_pages(monkeypatch):
    from demand_forecasting import monitoring_store
    f=pd.concat([frame(),frame()],ignore_index=True)
    f['hex_id_7']=['a','b'];f['travel_mode']='Car';f['horizon_minutes']=30;f['model_version']='v1'
    monkeypatch.setattr(monitoring_store,'load_evaluation',lambda *a,**kw:f)
    app=FastAPI();register(app);client=TestClient(app)
    query=dict(kind='performance',start=T.isoformat(),end=(T+pd.Timedelta(hours=1)).isoformat(),travel_mode='Car',horizon_minutes=30,model_version='v1',limit=1)
    response=client.get('/details',params=query)
    assert response.status_code==200,response.text
    result=response.json();assert result['total']==2 and len(result['rows'])==1
    query['hex_id']='b'
    assert client.get('/details',params=query).json()['rows'][0]['hex_id_7']=='b'


def test_feature_evidence_is_written_as_valid_json():
    from types import SimpleNamespace
    from demand_forecasting.monitoring_details import save_feature_detail
    import json
    class Connection:
        def __init__(self): self.calls=[]
        def execute(self,query,params=None): self.calls.append((query.as_string(),params))
    conn=Connection()
    frame=pd.DataFrame({'hex_id_7':['a'],'lag_10m':[np.nan]})
    raw=pd.DataFrame(columns=['hex_id_7','travel_mode','period_datetime_utc'])
    snapshot=measure(frame,['lag_10m'],raw,T,'Car',10,'v1',now=T)
    save_feature_detail(conn,SimpleNamespace(postgres_schema='public'),snapshot)
    query,params=conn.calls[-1]
    assert 'ON CONFLICT' in query
    payload=json.loads(json.dumps(params[-1].obj,allow_nan=False))
    assert payload['detail_rows'][0]['hex_id_7']=='a'
    assert payload['detail_rows'][0]['latest_bucket_utc'] is None
