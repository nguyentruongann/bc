# Nối cảnh báo 8001 với bản đồ 8000

Bản vá này áp dụng SAU bản monitor_details_changed_files.zip đã gửi trước đó.

Ghi đè hai file trong src/demand_forecasting/dashboard_assets/:
- app.js
- monitoring.html

Giữ nguyên các file Python của bản cập nhật chi tiết cảnh báo trước đó.

Tại thư mục dự án, chạy:

docker compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d --build --no-deps api monitor

Sau đó tải lại cả hai trang bằng Ctrl+F5 (hoặc xóa cache trang nếu dùng điện thoại).

Ở cổng 8001: bấm Xem chi tiết trong Feature/Performance, rồi bấm Xem trên bản đồ ở dòng hex muốn tra. Trang 8000/dashboard mở trong tab mới, giữ hostname và giao thức của trang monitor, mang theo mã hex, loại xe, horizon, thời điểm dự báo và model version. Bản đồ tự căn giữa, phóng to, tô viền và mở chi tiết hex.

Nếu không có batch tại thời điểm đó hoặc hex không có prediction, trang báo rõ và không tự chuyển sang mốc mới nhất. Phiên bản model khác cảnh báo cũng được thông báo. Bộ lọc của người dùng sau khi mở trang vẫn dùng bình thường. Đây là liên kết tới cổng 8000 theo yêu cầu; nếu API_PORT khác 8000, cần chỉnh giá trị url.port trong monitoring.html.

Đã kiểm tra bằng DOM giả lập: truyền đủ bộ lọc, chọn/tô viền hex và gọi API chi tiết, hex không tồn tại, batch trả 404, link sang đúng /dashboard. Chưa chạy trên Docker/PostgreSQL thật của người dùng.
